#Gabriel maurilio

num1 = int(input("digite o primeiro numero"))
num2 = int(input("digite o segundo numero"))
num3 = int(input("digite o terceiro numero"))

if num1 > num2 or num3:
   print(num1 > num2 or num3 )
if num1 < num2 or num3:
   print(num3 < num2 or num1)

