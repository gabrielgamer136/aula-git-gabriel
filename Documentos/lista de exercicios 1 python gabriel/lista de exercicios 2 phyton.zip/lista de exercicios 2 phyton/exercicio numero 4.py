#Gabriel maurilio
num1 = int(input("digite o primeiro numero"))
num2 = int(input("digite o segundo numero"))
num3 = int(input("digite o terceiro numero"))

if num1 > num2 and num1 > num3: 
   print(num1) 
else:
 if num2 > num1 and num2 > num3:
    print(num2) 
 else:
   if num3 > num2 and num1 or num2: 
      print(num3)  
